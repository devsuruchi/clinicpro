import React, { useState, useEffect } from "react";
import { 
  Activity, 
  Database, 
  Lock, 
  Mail, 
  Plus, 
  Search, 
  Trash2, 
  Edit, 
  LogOut, 
  Users, 
  ClipboardList, 
  CheckCircle2, 
  Clock, 
  UserCheck, 
  RefreshCw, 
  SlidersHorizontal, 
  AlertCircle, 
  Heart, 
  Calendar,
  X,
  PlusCircle,
  FileText,
  Phone,
  ArrowRight
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { PatientRecord, DBStatus } from "./types";

export default function App() {
  // Authentication & Session
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("axis_physio_token"));
  const [user, setUser] = useState<{ email: string; name: string; role: string } | null>(() => {
    const saved = localStorage.getItem("axis_physio_user");
    return saved ? JSON.parse(saved) : null;
  });

  // Database Connection Indicator
  const [dbStatus, setDbStatus] = useState<DBStatus | null>(null);
  const [isRefreshingStatus, setIsRefreshingStatus] = useState(false);
  const [showDbInfo, setShowDbInfo] = useState(false);

  // Clinical Records Collection
  const [records, setRecords] = useState<PatientRecord[]>([]);
  const [isLoadingRecords, setIsLoadingRecords] = useState(false);

  // Form Controllers
  const [isLoginLoading, setIsLoginLoading] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");

  // Record Modification Modal Controllers
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [modalMode, setModalMode] = useState<"Create" | "Edit">("Create");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [modalError, setModalError] = useState("");

  // Form Fields
  const [patientName, setPatientName] = useState("");
  const [patientAge, setPatientAge] = useState("");
  const [patientGender, setPatientGender] = useState("Male");
  const [contactNumber, setContactNumber] = useState("");
  const [diagnosis, setDiagnosis] = useState("");
  const [treatment, setTreatment] = useState("");
  const [assignedTherapist, setAssignedTherapist] = useState("");
  const [recordStatus, setRecordStatus] = useState<"Active" | "Completed" | "Scheduled">("Active");
  const [nextSession, setNextSession] = useState("");

  // Search & Filtering Queries
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | "Active" | "Completed" | "Scheduled">("All");

  // Notifications
  const [notification, setNotification] = useState<{ type: "success" | "error"; message: string } | null>(null);

  // Auto-hide notifications
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  // Fetch Connection / Database configuration details
  const fetchDBStatus = async () => {
    setIsRefreshingStatus(true);
    try {
      const res = await fetch("/api/system/status");
      if (res.ok) {
        const data = await res.json();
        setDbStatus(data);
      }
    } catch (err) {
      console.error("Failed to read system status:", err);
    } finally {
      setIsRefreshingStatus(false);
    }
  };

  // Pull Records (Only if authorized token is present)
  const fetchRecords = async () => {
    if (!token) return;
    setIsLoadingRecords(true);
    try {
      const res = await fetch("/api/records", {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });
      if (res.ok) {
        const data = await res.json();
        setRecords(data);
      } else {
        // Token has expired or is invalid
        if (res.status === 401 || res.status === 403) {
          handleLogout();
          triggerNotification("error", "Your session has expired. Please log in again.");
        }
      }
    } catch (err) {
      console.error("Clinical record load failure:", err);
      triggerNotification("error", "Unable to pull clinic files from server.");
    } finally {
      setIsLoadingRecords(false);
    }
  };

  // Initial load
  useEffect(() => {
    fetchDBStatus();
    if (token) {
      fetchRecords();
    }
  }, [token]);

  const triggerNotification = (type: "success" | "error", message: string) => {
    setNotification({ type, message });
  };

  // Quick fill user login parameters
  const handleQuickFill = (email: string) => {
    setLoginEmail(email);
    setLoginPassword("AxisPass2026!"); // Default seeded encrypted password
    setLoginError("");
  };

  // Sign In submit handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginEmail || !loginPassword) {
      setLoginError("Please enter both email and password.");
      return;
    }

    setIsLoginLoading(true);
    setLoginError("");

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: loginEmail, password: loginPassword })
      });

      const data = await res.json();

      if (res.ok) {
        localStorage.setItem("axis_physio_token", data.token);
        localStorage.setItem("axis_physio_user", JSON.stringify(data.user));
        setToken(data.token);
        setUser(data.user);
        triggerNotification("success", `Authorized successfully as Dr. ${data.user.name}`);
      } else {
        setLoginError(data.error || "Authentication failed. Double check credentials.");
      }
    } catch (err) {
      console.error("Auth call failure:", err);
      setLoginError("Authentication server unreachable. Confirm node runs properly.");
    } finally {
      setIsLoginLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("axis_physio_token");
    localStorage.removeItem("axis_physio_user");
    setToken(null);
    setUser(null);
    setRecords([]);
  };

  // Open Form modal for creation
  const handleOpenCreateModal = () => {
    setModalMode("Create");
    setEditingId(null);
    setPatientName("");
    setPatientAge("35");
    setPatientGender("Male");
    setContactNumber("");
    setDiagnosis("");
    setTreatment("");
    setAssignedTherapist(user?.name ? "Dr. " + user.name.replace(/^Dr\.\s*/, "") : "Dr. Suruchi");
    setRecordStatus("Active");
    setNextSession("");
    setModalError("");
    setIsModalOpen(true);
  };

  // Open Form modal for editing
  const handleOpenEditModal = (rec: PatientRecord) => {
    setModalMode("Edit");
    setEditingId(rec.id);
    setPatientName(rec.patientName);
    setPatientAge(rec.age.toString());
    setPatientGender(rec.gender);
    setContactNumber(rec.contactNumber);
    setDiagnosis(rec.diagnosis);
    setTreatment(rec.treatment);
    setAssignedTherapist(rec.assignedTherapist);
    setRecordStatus(rec.status);
    setNextSession(rec.nextSession || "");
    setModalError("");
    setIsModalOpen(true);
  };

  // Submit record creation / updates
  const handleRecordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientName || !diagnosis || !treatment) {
      setModalError("Patient Name, Primary Diagnosis, and Treatment details are required.");
      return;
    }

    setIsSubmitting(true);
    setModalError("");

    const bodyData = {
      patientName,
      age: parseInt(patientAge) || 30,
      gender: patientGender,
      contactNumber,
      diagnosis,
      treatment,
      assignedTherapist,
      status: recordStatus,
      nextSession: nextSession || ""
    };

    try {
      const url = modalMode === "Create" ? "/api/records" : `/api/records/${editingId}`;
      const method = modalMode === "Create" ? "POST" : "PUT";

      const res = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(bodyData)
      });

      const data = await res.json();
      if (res.ok) {
        triggerNotification(
          "success", 
          modalMode === "Create" 
            ? "Successfully created patient record file." 
            : "Successfully updated patient record file."
        );
        setIsModalOpen(false);
        fetchRecords(); // Refresh listings
      } else {
        setModalError(data.error || "Failed to save record. Try again.");
      }
    } catch (err) {
      console.error("Save failure:", err);
      setModalError("Server unreachable. Please verify system is active.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Deletion logic
  const handleDeleteRecord = async (id: string, name: string) => {
    if (!window.confirm(`Are you sure you want to delete patient clinical history for ${name}?`)) {
      return;
    }

    try {
      const res = await fetch(`/api/records/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });
      if (res.ok) {
        triggerNotification("success", `Removed clinical historical file for ${name}.`);
        fetchRecords();
      } else {
        const errData = await res.json();
        triggerNotification("error", errData.error || "Could not delete file folder.");
      }
    } catch (err) {
      triggerNotification("error", "Failed to contact database backend.");
    }
  };

  // Filtering list locally
  const filteredRecords = records.filter(rec => {
    const term = searchQuery.toLowerCase();
    const matchSearch = 
      rec.patientName.toLowerCase().includes(term) ||
      rec.diagnosis.toLowerCase().includes(term) ||
      rec.assignedTherapist.toLowerCase().includes(term);
    
    if (statusFilter === "All") return matchSearch;
    return matchSearch && rec.status === statusFilter;
  });

  // Compute Statistics Counters
  const stats = {
    total: records.length,
    active: records.filter(r => r.status === "Active").length,
    completed: records.filter(r => r.status === "Completed").length,
    scheduled: records.filter(r => r.status === "Scheduled").length
  };

  return (
    <div id="axis-root" className="min-h-screen bg-[#F9F9F9] text-black font-sans antialiased selection:bg-[#C084FC] selection:text-black border-8 md:border-[16px] border-black flex flex-col pb-8">
      {/* Toast Notification */}
      <AnimatePresence>
        {notification && (
          <motion.div 
            id="toast-notification"
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className={`fixed top-6 right-6 z-50 flex items-center gap-3 px-6 py-4 rounded-none border-4 border-black font-black text-xs uppercase tracking-wider shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] ${
              notification.type === "success" 
                ? "bg-[#C084FC] text-black" 
                : "bg-red-500 text-white"
            }`}
          >
            {notification.type === "success" ? (
              <CheckCircle2 className="h-5 w-5 text-black shrink-0 stroke-[3px]" />
            ) : (
              <AlertCircle className="h-5 w-5 text-white shrink-0 stroke-[3px]" />
            )}
            <p className="font-black">{notification.message}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Header Branding Banner */}
      <header id="clinical-brand-header" className="bg-white border-b-4 border-black sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-5 flex flex-col md:flex-row gap-6 justify-between items-stretch md:items-end">
          <div className="flex flex-col sm:flex-row sm:items-end gap-4">
            <div className="h-14 w-14 border-4 border-black bg-black flex items-center justify-center text-white shrink-0 shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
              <Activity className="h-8 w-8 stroke-[3px]" />
            </div>
            <div>
              <div className="flex flex-col sm:flex-row sm:items-end gap-2 sm:gap-3">
                <h1 className="text-3xl sm:text-4xl md:text-5xl font-black uppercase leading-none tracking-tighter">AXIS PHYSIOTHERAPY</h1>
                <span className="text-[11px] font-black bg-black text-white px-2.5 py-1 rounded-none uppercase font-mono tracking-wider w-fit">PVT. LTD.</span>
              </div>
              <p className="text-xs font-black tracking-[0.2em] sm:tracking-[0.3em] uppercase opacity-75 mt-2">Clinic Record Management // Admin Portal</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 justify-between md:justify-end">
            {/* Database status pill */}
            <div id="db-status-trigger" className="relative">
              <button 
                onClick={() => setShowDbInfo(!showDbInfo)}
                className={`flex items-center gap-2 py-2 px-4 rounded-none text-xs font-black uppercase border-3 border-black cursor-pointer transition-all shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:bg-neutral-100 ${
                  dbStatus?.connected 
                    ? "bg-[#C084FC] text-black" 
                    : "bg-white text-black"
                }`}
              >
                <Database className="h-4 w-4 stroke-[2.5px]" />
                <span>{dbStatus?.connected ? "NeonDB Active" : "Sandbox Database"}</span>
              </button>
              
              <AnimatePresence>
                {showDbInfo && (
                  <motion.div 
                    id="db-details-drawer"
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="absolute right-0 mt-3 w-80 bg-white rounded-none border-4 border-black p-5 z-50 text-xs text-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]"
                  >
                    <div className="flex justify-between items-center border-b-2 border-black pb-2 mb-3">
                      <span className="font-black text-sm uppercase tracking-wider">Database Environment</span>
                      <button onClick={() => setShowDbInfo(false)} className="text-black hover:bg-neutral-100 p-1 border border-black cursor-pointer">
                        <X className="h-4 w-4 stroke-[3px]" />
                      </button>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <span className="font-black block text-neutral-500 uppercase text-[9px] tracking-wider">ACTIVE PROVIDER</span>
                        <div className="flex items-center gap-1.5 mt-1 font-black text-sm uppercase">
                          <span className={`h-3 w-3 border border-black ${dbStatus?.connected ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                          {dbStatus?.provider || "Local Discovered Storage"}
                        </div>
                      </div>

                      {dbStatus?.connected ? (
                        <div>
                          <span className="font-black block text-neutral-500 uppercase text-[9px] tracking-wider">NEON INTERFACE STRING</span>
                          <span className="font-mono text-[11px] text-black bg-[#F0F0F0] p-2 mt-1 block border border-black leading-tight break-all">
                            {dbStatus.connectionStringBlurry}
                          </span>
                        </div>
                      ) : (
                        <div className="bg-[#C084FC] border-2 border-black p-3 text-black text-[11px] leading-normal font-bold">
                          <p className="font-black uppercase mb-1">💡 Sandbox File System Active</p>
                          To link your live Postgres DB, set <code className="font-mono bg-black text-white px-1 font-bold">DATABASE_URL</code> in the secrets section.
                        </div>
                      )}

                      <div className="pt-3 border-t border-dashed border-black/30 flex justify-between items-center">
                        <span className="text-[10px] uppercase font-bold text-neutral-500">2026-06-12 UT</span>
                        <button 
                          onClick={fetchDBStatus} 
                          disabled={isRefreshingStatus}
                          className="flex items-center gap-1 text-black font-black uppercase text-[10px] tracking-wider hover:underline cursor-pointer"
                        >
                          <RefreshCw className={`h-3 w-3 stroke-[2.5px] ${isRefreshingStatus ? 'animate-spin' : ''}`} />
                          Sync State
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {user && (
              <div className="flex items-center gap-4 pl-4 border-t md:border-t-0 md:border-l-4 border-black pt-4 md:pt-0">
                <div className="text-right">
                  <span className="text-sm font-black uppercase tracking-tight block leading-none">{user.name}</span>
                  <span className="text-[10px] text-neutral-600 font-bold block mt-1 uppercase">
                    Role: <span className="bg-[#C084FC] border border-black px-1.5 py-0.5 text-black font-black">{user.role}</span>
                  </span>
                </div>
                <button 
                  id="header-logout-btn"
                  onClick={handleLogout} 
                  className="px-3 py-2 bg-black hover:bg-neutral-200 text-white hover:text-black border-2 border-black font-black uppercase text-xs tracking-wider cursor-pointer transition-colors"
                  title="Logout Session"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Container Core Routing Layout */}
      <main id="clinical-record-router" className="max-w-7xl mx-auto px-6 mt-8 w-full flex-1">
        {!token ? (
          /* Authentication Screen Trigger */
          <div id="authentication-module" className="max-w-md mx-auto my-12">
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden"
            >
              {/* Header Visual Section */}
              <div className="bg-black p-8 text-center text-white relative">
                <div className="inline-flex h-14 w-14 border-2 border-white bg-white text-black items-center justify-center font-black mb-4 shadow-[2px_2px_0px_0px_rgba(255,255,255,1)]">
                  <Activity className="h-8 w-8 stroke-[3.5px]" />
                </div>
                <h2 className="text-3xl font-black uppercase tracking-tight">CLINIC PORTAL GATE</h2>
                <p className="text-[#C084FC] text-xs mt-2 font-black uppercase tracking-widest">
                  AUTHORIZATION REQUIRED TO ACCESS HISTORICAL HEALTH FILES
                </p>
              </div>

              {/* Login form */}
              <form onSubmit={handleLogin} className="p-8 space-y-6 bg-white">
                {loginError && (
                  <div className="p-4 bg-red-500 text-white border-2 border-black font-bold uppercase text-xs flex gap-2 items-start leading-relaxed shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                    <AlertCircle className="h-4.5 w-4.5 shrink-0 stroke-[3px]" />
                    <span>{loginError}</span>
                  </div>
                )}

                <div className="space-y-4">
                  {/* Email */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Admin Email ID</label>
                    <div className="relative">
                      <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-black" />
                      <input 
                        type="email" 
                        required
                        value={loginEmail}
                        onChange={(e) => { setLoginEmail(e.target.value); setLoginError(""); }}
                        placeholder="ADMIN@AXISPHYSIO.COM"
                        className="w-full pl-11 pr-4 py-3 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm font-black uppercase placeholder-neutral-400 bg-white"
                      />
                    </div>
                  </div>

                  {/* Password */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">User Key Password</label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-black" />
                      <input 
                        type="password" 
                        required
                        value={loginPassword}
                        onChange={(e) => { setLoginPassword(e.target.value); setLoginError(""); }}
                        placeholder="••••••••••••••"
                        className="w-full pl-11 pr-4 py-3 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm font-black uppercase placeholder-neutral-400 bg-white"
                      />
                    </div>
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={isLoginLoading}
                  className="w-full py-3 px-4 rounded-none bg-[#C084FC] text-black hover:bg-black hover:text-[#C084FC] border-2 border-black font-black uppercase text-xs tracking-widest cursor-pointer transition-all shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none flex items-center justify-center gap-2"
                >
                  {isLoginLoading ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin stroke-[3px]" />
                      VERIFYING USER SEGMENT...
                    </>
                  ) : (
                    <>
                      <span>UNLOCK CLINICAL RECORDS</span>
                      <ArrowRight className="h-4 w-4 stroke-[3px]" />
                    </>
                  )}
                </button>
              </form>

              {/* Seed / Default quick credentials interface */}
              <div className="px-8 pb-8 pt-6 bg-[#F0F0F0] border-t-4 border-black">
                <span className="block text-xs font-black text-black uppercase tracking-wider mb-3 text-center">SEEDED CLINIC ACCESS FILES</span>
                <div className="space-y-3">
                  <button 
                    onClick={() => handleQuickFill("admin@axisphysio.com")}
                    type="button"
                    className="w-full bg-white hover:bg-[#C084FC] border-2 border-black text-left p-3 rounded-none cursor-pointer transition-all flex items-center justify-between shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:shadow-none"
                  >
                    <div>
                      <span className="font-black uppercase text-xs block text-black">AXIS ADMINISTRATOR</span>
                      <span className="text-[10px] text-neutral-600 font-mono">admin@axisphysio.com</span>
                    </div>
                    <UserCheck className="h-4.5 w-4.5 text-black stroke-[2.5px]" />
                  </button>

                  <button 
                    onClick={() => handleQuickFill("suruchidevchaudhary@gmail.com")}
                    type="button"
                    className="w-full bg-white hover:bg-[#C084FC] border-2 border-black text-left p-3 rounded-none cursor-pointer transition-all flex items-center justify-between shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:shadow-none"
                  >
                    <div>
                      <span className="font-black uppercase text-xs block text-black">DR. SURUCHI (CHIEF PHYSIO)</span>
                      <span className="text-[10px] text-neutral-600 font-mono">suruchidevchaudhary@gmail.com</span>
                    </div>
                    <UserCheck className="h-4.5 w-4.5 text-black stroke-[2.5px]" />
                  </button>
                </div>
                <div className="text-[9px] text-neutral-500 justify-center flex items-center gap-1.5 mt-4 uppercase font-bold">
                  <Lock className="h-3.5 w-3.5 text-black" />
                  <span>Passwords are robustly salted & encrypted in Database</span>
                </div>
              </div>
            </motion.div>
          </div>
        ) : (
          /* Protected Admin Dashboard Access Panel */
          <div id="authorized-admin-panel" className="space-y-6">
            {/* Database mode persistent explanation bar */}
            {!dbStatus?.connected && (
              <div className="p-6 bg-[#C084FC] border-4 border-black rounded-none flex flex-col md:flex-row justify-between md:items-center gap-4 text-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                <div className="flex gap-3 items-start">
                  <AlertCircle className="h-6 w-6 text-black shrink-0 stroke-[2.5px]" />
                  <div>
                    <h4 className="text-sm font-black uppercase tracking-wider">SANDBOX PERSISTENCY ACTIVE</h4>
                    <p className="text-xs mt-1 leading-relaxed font-bold uppercase">
                      The application is currently falling back to filesystem files inside the container.
                      To activate production-grade Neon PostgreSQL via Prisma, set your URL as <code className="font-mono bg-black text-white px-1.5 py-0.5 select-all text-xs font-bold font-black">DATABASE_URL</code> in your Secrets Settings.
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowDbInfo(true)}
                  className="text-xs bg-black hover:bg-white hover:text-black text-white font-black uppercase tracking-widest py-2.5 px-4 border-2 border-black transition-colors cursor-pointer shrink-0"
                >
                  Configure Server Key
                </button>
              </div>
            )}

            {/* Quick Overview Statistics Row */}
            <section id="metrics-overview" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 border-4 border-black rounded-none flex items-center gap-4 shadow-[4px_4px_0px_1px_rgba(0,0,0,1)] transition-transform hover:-translate-y-0.5">
                <div className="h-12 w-12 border-2 border-black bg-black text-white flex items-center justify-center shrink-0">
                  <ClipboardList className="h-6 w-6 stroke-[2.5px]" />
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 font-black uppercase tracking-wider block">Total Patients</span>
                  <span className="text-2xl sm:text-3xl font-black text-black block mt-0.5 leading-none">
                    {isLoadingRecords ? "..." : stats.total}
                  </span>
                </div>
              </div>

              <div className="bg-[#C084FC] p-5 border-4 border-black rounded-none flex items-center gap-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-transform hover:-translate-y-0.5 text-black">
                <div className="h-12 w-12 border-2 border-black bg-black text-white flex items-center justify-center shrink-0">
                  <Activity className="h-6 w-6 stroke-[2.5px]" />
                </div>
                <div>
                  <span className="text-[10px] text-black font-black uppercase tracking-wider block">Active Treatment</span>
                  <span className="text-2xl sm:text-3xl font-black text-black block mt-0.5 leading-none">
                    {isLoadingRecords ? "..." : stats.active}
                  </span>
                </div>
              </div>

              <div className="bg-white p-5 border-4 border-black rounded-none flex items-center gap-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-transform hover:-translate-y-0.5">
                <div className="h-12 w-12 border-2 border-black bg-black text-white flex items-center justify-center shrink-0">
                  <Clock className="h-6 w-6 stroke-[2.5px]" />
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 font-black uppercase tracking-wider block">Scheduled Next</span>
                  <span className="text-2xl sm:text-3xl font-black text-black block mt-0.5 leading-none">
                    {isLoadingRecords ? "..." : stats.scheduled}
                  </span>
                </div>
              </div>

              <div className="bg-black p-5 border-4 border-black rounded-none flex items-center gap-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-transform hover:-translate-y-0.5 text-white">
                <div className="h-12 w-12 border-2 border-white bg-white text-black flex items-center justify-center shrink-0">
                  <CheckCircle2 className="h-6 w-6 stroke-[2.5px]" />
                </div>
                <div>
                  <span className="text-[10px] text-neutral-400 font-black uppercase tracking-wider block">Completed Cases</span>
                  <span className="text-2xl sm:text-3xl font-black text-white block mt-0.5 leading-none">
                    {isLoadingRecords ? "..." : stats.completed}
                  </span>
                </div>
              </div>
            </section>

            {/* Patients management and core controls card */}
            <div className="bg-white border-4 border-black rounded-none shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] overflow-hidden">
              {/* Table search, status filters, addition action controls bar */}
              <div className="p-6 border-b-4 border-black bg-[#F0F0F0] flex flex-col lg:flex-row gap-4 justify-between items-stretch lg:items-center">
                <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center flex-1">
                  {/* Local Search Input */}
                  <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4.5 w-4.5 text-black" />
                    <input 
                      type="text" 
                      placeholder="SEARCH DIAGNOSIS or NAME..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-black uppercase placeholder-neutral-500 bg-white"
                    />
                    {searchQuery && (
                      <button 
                        onClick={() => setSearchQuery("")}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-black hover:bg-neutral-200 p-1 border border-black"
                      >
                        <X className="h-3.5 w-3.5 strike-[3px]" />
                      </button>
                    )}
                  </div>

                  {/* Status selection slider */}
                  <div className="flex items-center gap-1 bg-white p-1 rounded-none border-2 border-black self-start">
                    {(["All", "Active", "Scheduled", "Completed"] as const).map((filter) => (
                      <button
                        key={filter}
                        onClick={() => setStatusFilter(filter)}
                        className={`text-xs font-black uppercase px-3.5 py-1.5 rounded-none transition-all cursor-pointer ${
                          statusFilter === filter 
                            ? "bg-black text-white" 
                            : "text-black hover:bg-neutral-200"
                        }`}
                      >
                        {filter}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Create patient folder trigger */}
                <button 
                  id="add-record-btn"
                  onClick={handleOpenCreateModal}
                  className="flex items-center justify-center gap-1.5 bg-[#C084FC] hover:bg-black hover:text-[#C084FC] text-black font-black uppercase py-2.5 px-5 rounded-none border-2 sm:border-3 border-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:shadow-none transition-all cursor-pointer text-sm"
                >
                  <Plus className="h-5 w-5 stroke-[3px]" />
                  <span>Log New Treatment</span>
                </button>
              </div>

              {/* Records rendering */}
              <div className="overflow-x-auto">
                {isLoadingRecords ? (
                  <div className="py-24 text-center">
                    <RefreshCw className="h-10 w-10 text-black animate-spin mx-auto mb-4 stroke-[2.5px]" />
                    <p className="text-black font-black uppercase tracking-widest text-xs">Securing records and loading physical folders...</p>
                  </div>
                ) : filteredRecords.length === 0 ? (
                  <div className="py-16 text-center max-w-sm mx-auto">
                    <div className="h-14 w-14 rounded-none border-2 border-black bg-neutral-100 flex items-center justify-center mx-auto mb-4 text-black shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                      <SlidersHorizontal className="h-6 w-6 stroke-[2.5px]" />
                    </div>
                    <h3 className="text-black font-black uppercase tracking-wider text-base mb-2">No Matching Files</h3>
                    <p className="text-xs text-neutral-600 leading-normal uppercase font-bold">
                      {searchQuery || statusFilter !== "All" 
                        ? "Query filter cleared zero matching records. Reset parameters to restore." 
                        : "No patient documents registered. Tap 'Log New Treatment' to register Axis physical diagnosis files."}
                    </p>
                    {(searchQuery || statusFilter !== "All") && (
                      <button 
                        onClick={() => { setSearchQuery(""); setStatusFilter("All"); }}
                        className="mt-4 text-xs text-black hover:underline font-black uppercase tracking-wider cursor-pointer"
                      >
                        Reset Search Parameters // CLEAR
                      </button>
                    )}
                  </div>
                ) : (
                  <table className="w-full text-black text-xs border-collapse">
                    <thead>
                      <tr className="bg-black text-white uppercase text-[10px] tracking-wider font-black border-r border-[#000000] text-left">
                        <th className="pl-6 pr-4 py-4 border-r border-neutral-700">Patient Folder / Code</th>
                        <th className="px-4 py-4 border-r border-neutral-700">Gender / Age</th>
                        <th className="px-4 py-4 border-r border-neutral-700">Clinical Diagnosis</th>
                        <th className="px-4 py-4 border-r border-neutral-700">Active Treatment Plan</th>
                        <th className="px-4 py-4 border-r border-neutral-700">Assigned Therapist</th>
                        <th className="px-4 py-4 border-r border-neutral-700 text-center">Case Stage</th>
                        <th className="px-4 py-4 border-r border-neutral-700">Next Scheduled</th>
                        <th className="pl-4 pr-6 py-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y-2 divide-black">
                      {filteredRecords.map((rec, idx) => (
                        <tr key={rec.id} className={`${idx % 2 === 1 ? 'bg-[#F9F9F9]' : 'bg-white'} hover:bg-neutral-100 transition-colors group`}>
                          {/* Folder Name & Index */}
                          <td className="pl-6 pr-4 py-4 whitespace-nowrap border-r-2 border-black">
                            <div className="flex items-center gap-3">
                              <div className="h-10 w-10 border-2 border-black bg-black text-white font-black flex items-center justify-center text-xs shrink-0 select-none uppercase">
                                {rec.patientName.split(" ").map(w => w[0]).join("").substring(0, 2)}
                              </div>
                              <div>
                                <span className="font-extrabold text-black block group-hover:text-red-700 transition-colors uppercase tracking-tight text-sm">{rec.patientName}</span>
                                <div className="flex items-center gap-1.5 mt-1 text-[11px] text-neutral-600 font-mono">
                                  <Phone className="h-3 w-3 text-black" />
                                  <span>{rec.contactNumber || "No Phone Contact"}</span>
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Age & Gender */}
                          <td className="px-4 py-4 whitespace-nowrap border-r-2 border-black">
                            <span className="text-black font-extrabold uppercase block">{rec.gender}</span>
                            <span className="text-[11px] text-neutral-600 block mt-1 font-mono">{rec.age} Years Old</span>
                          </td>

                          {/* Diagnosis */}
                          <td className="px-4 py-4 border-r-2 border-black">
                            <div className="max-w-xs">
                              <span className="font-extrabold text-black uppercase tracking-tight line-clamp-2 leading-snug">{rec.diagnosis}</span>
                            </div>
                          </td>

                          {/* Treatment Modal */}
                          <td className="px-4 py-4 border-r-2 border-black">
                            <span className="text-xs text-neutral-700 block leading-relaxed font-mono max-w-sm line-clamp-3">
                              {rec.treatment}
                            </span>
                          </td>

                          {/* assigned therapist */}
                          <td className="px-4 py-4 whitespace-nowrap border-r-2 border-black">
                            <span className="text-xs font-black text-black bg-[#C084FC] border-2 border-black px-2.5 py-1 block w-fit uppercase">
                              {rec.assignedTherapist}
                            </span>
                          </td>

                          {/* Status */}
                          <td className="px-4 py-4 whitespace-nowrap text-center border-r-2 border-black">
                            <span className={`inline-flex items-center gap-1 px-3 py-1.5 border-2 border-black text-[11px] font-black uppercase tracking-wider ${
                              rec.status === "Active" 
                                ? "bg-[#C084FC] text-black" 
                                : rec.status === "Completed"
                                ? "bg-black text-white"
                                : "bg-white text-black"
                            }`}>
                              <span>{rec.status}</span>
                            </span>
                          </td>

                          {/* next appointments */}
                          <td className="px-4 py-4 whitespace-nowrap border-r-2 border-black">
                            {rec.nextSession ? (
                              <div className="flex items-center gap-1.5 px-2 py-1 text-xs font-black text-black bg-white border-2 border-black w-fit uppercase">
                                <Calendar className="h-4 w-4 text-black" />
                                <span className="font-mono">{rec.nextSession}</span>
                              </div>
                            ) : (
                              <span className="text-[11px] italic text-neutral-400 uppercase font-bold">No date set</span>
                            )}
                          </td>

                          {/* Triggers */}
                          <td className="pl-4 pr-6 py-4 whitespace-nowrap text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button 
                                onClick={() => handleOpenEditModal(rec)}
                                className="p-2 bg-white hover:bg-[#C084FC] text-black border-2 border-black font-extrabold text-xs cursor-pointer transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none"
                                title="Edit History File"
                              >
                                <Edit className="h-4 w-4 stroke-[2.5px]" />
                              </button>
                              <button 
                                onClick={() => handleDeleteRecord(rec.id, rec.patientName)}
                                className="p-2 bg-red-500 hover:bg-black text-white hover:text-red-500 border-2 border-black font-extrabold text-xs cursor-pointer transition-colors shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-none"
                                title="Delete History File"
                              >
                                <Trash2 className="h-4 w-4 stroke-[2.5px]" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Total counter helper footer */}
              {!isLoadingRecords && filteredRecords.length > 0 && (
                <div className="px-6 py-4 bg-[#F0F0F0] border-t-4 border-black flex justify-between items-center text-[10px] sm:text-xs text-black font-black uppercase tracking-wider">
                  <span>Displaying {filteredRecords.length} of {records.length} patients in archive</span>
                  <span className="font-mono text-[10px] tracking-normal font-medium">SYS_REF: 2026-06-12 UT</span>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Dynamic Creation & Modification Slide drawer panel Overlay */}
      <AnimatePresence>
        {isModalOpen && (
          <div id="modal-backdrop" className="fixed inset-0 bg-black/75 z-50 flex justify-end">
            {/* Modal Drawer Body Container */}
            <motion.div 
              id="clinical-form-panel"
              initial={{ x: "100%", opacity: 0.9 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: "100%", opacity: 0.9 }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className="w-full max-w-lg bg-white h-full border-l-8 border-black flex flex-col relative shadow-[0px_0px_50px_0px_rgba(0,0,0,0.5)]"
            >
              <div className="p-6 border-b-4 border-black flex justify-between items-center bg-black text-white select-none">
                <div className="flex items-center gap-2">
                  <FileText className="h-6 w-6 text-[#C084FC] stroke-[2.5px]" />
                  <div>
                    <h2 className="text-lg font-black uppercase tracking-tight">{modalMode === "Create" ? "Record Clinical Diagnosis" : "Edit Historical File"}</h2>
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider block font-bold mt-1">AXIS PHYSIOTHERAPY // ADMINISTRATIVE DB</span>
                  </div>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-1 border-2 border-white hover:bg-[#C084FC] hover:text-black hover:border-black transition-colors cursor-pointer text-white"
                >
                  <X className="h-5 w-5 stroke-[2.5px]" />
                </button>
              </div>

              {/* Input Form Scrollable */}
              <form onSubmit={handleRecordSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
                {modalError && (
                  <div className="p-4 bg-red-500 text-white border-2 border-black font-bold uppercase text-xs flex gap-2 items-start leading-relaxed shadow-[3px_3px_0px_0px_rgba(0,0,0,1)]">
                    <AlertCircle className="h-4.5 w-4.5 text-white shrink-0 stroke-[3px]" />
                    <span>{modalError}</span>
                  </div>
                )}

                {/* Section titles */}
                <div className="text-xs font-black uppercase tracking-widest text-[#000000] border-b-2 border-black pb-1.5">PATIENT INFORMATION CARD</div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name field */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Full Patient Name</label>
                    <input 
                      type="text" 
                      required
                      placeholder="E.G. SURUCHI DEVI CHAUDHARY"
                      value={patientName}
                      onChange={(e) => setPatientName(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-extrabold uppercase bg-white"
                    />
                  </div>

                  {/* Age */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Age (Years)</label>
                    <input 
                      type="number" 
                      required
                      min="1"
                      max="125"
                      value={patientAge}
                      onChange={(e) => setPatientAge(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-extrabold uppercase bg-white"
                    />
                  </div>

                  {/* Gender Select */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Assigned Gender</label>
                    <select 
                      value={patientGender}
                      onChange={(e) => setPatientGender(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-extrabold uppercase bg-white cursor-pointer"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Non-Binary">Non-Binary</option>
                      <option value="Prefer Not to Say">Prefer Not to Say</option>
                    </select>
                  </div>

                  {/* Contact Number */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Contact Phone Number</label>
                    <input 
                      type="tel" 
                      placeholder="E.G. +91 98765 43210"
                      value={contactNumber}
                      onChange={(e) => setContactNumber(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-extrabold uppercase bg-white"
                    />
                  </div>
                </div>

                {/* Section title medical */}
                <div className="text-xs font-black uppercase tracking-widest text-[#000000] border-b-2 border-black pb-1.5">DIAGNOSTIC & PHYSICAL MODALITY</div>

                <div className="space-y-4">
                  {/* Diagnosis */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Clinical Diagnosis & Symptoms</label>
                    <textarea 
                      required
                      placeholder="E.G. FROZEN SHOULDER (ADHESIVE CAPSULITIS) WITH RESTRICTED ABDUCTION UP TO 90 DEGREES."
                      rows={3}
                      value={diagnosis}
                      onChange={(e) => setDiagnosis(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-mono font-medium bg-white uppercase resize-none"
                    />
                  </div>

                  {/* Treatment modality */}
                  <div>
                    <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Prescribed Physical Modality Plan</label>
                    <textarea 
                      required
                      placeholder="E.G. JOINT MOBILIZATION (MAITLAND GRADE II), SHORTWAVE DIATHERMY (SWD), AND ACTIVE PASSIVE MOVEMENTS."
                      rows={3}
                      value={treatment}
                      onChange={(e) => setTreatment(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-mono font-medium bg-white uppercase resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* assigned Therapist */}
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Physiotherapist In-charge</label>
                      <input 
                        type="text" 
                        required
                        placeholder="E.G. DR. SURUCHI"
                        value={assignedTherapist}
                        onChange={(e) => setAssignedTherapist(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-extrabold uppercase bg-white"
                      />
                    </div>

                    {/* Next scheduled session */}
                    <div>
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-1.5">Next Session Date</label>
                      <input 
                        type="date" 
                        value={nextSession}
                        min="2026-06-12"
                        onChange={(e) => setNextSession(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-none border-2 border-black outline-hidden focus:bg-yellow-50 focus:border-black text-sm text-black font-extrabold bg-white cursor-pointer"
                      />
                    </div>

                    {/* Status */}
                    <div className="sm:col-span-2">
                      <label className="block text-xs font-black uppercase tracking-wider text-black mb-2">Patient Case Stage Status</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(["Active", "Scheduled", "Completed"] as const).map((st) => (
                          <button
                            key={st}
                            type="button"
                            onClick={() => setRecordStatus(st)}
                            className={`py-2 rounded-none text-xs font-black uppercase border-2 border-black transition-all text-center cursor-pointer ${
                              recordStatus === st 
                                ? "bg-[#C084FC] text-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]" 
                                : "bg-white text-neutral-600 hover:bg-neutral-100"
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Submit action */}
                <div className="pt-4 border-t-2 border-black flex gap-3 justify-end">
                  <button 
                    type="button" 
                    onClick={() => setIsModalOpen(false)}
                    className="py-2.5 px-4 rounded-none border-2 border-black hover:bg-neutral-100 text-black font-black uppercase text-xs cursor-pointer transition-colors"
                  >
                    Cancel Block
                  </button>
                  <button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="py-2.5 px-5 rounded-none bg-[#C084FC] text-black border-2 border-black hover:bg-black hover:text-[#C084FC] font-black uppercase text-xs tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-colors shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] hover:shadow-none"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin stroke-[3px]" />
                        Saving Logs...
                      </>
                    ) : (
                      <>
                        <span>{modalMode === "Create" ? "Register Folder" : "Apply Updates"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
