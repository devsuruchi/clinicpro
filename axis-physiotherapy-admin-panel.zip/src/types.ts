export interface User {
  id: string;
  email: string;
  name: string;
  role: "ADMIN" | "STAFF";
}

export interface PatientRecord {
  id: string;
  patientName: string;
  age: number;
  gender: string;
  contactNumber: string;
  diagnosis: string;
  treatment: string;
  assignedTherapist: string;
  status: "Active" | "Completed" | "Scheduled";
  nextSession?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DBStatus {
  connected: boolean;
  provider: "Neon Postgres" | "Sandbox JSON";
  connectionStringBlurry: string;
  filePath: string;
  defaultAdminCredentials: {
    email: string;
    password: string;
  };
}
