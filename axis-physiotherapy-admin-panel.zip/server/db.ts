import { PrismaClient } from "@prisma/client";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";

// Types matching the Prisma model definitions
export interface User {
  id: string;
  email: string;
  password?: string; // Hashed password
  name: string;
  role: "ADMIN" | "STAFF";
  createdAt: Date;
}

export interface PatientRecord {
  id: string;
  patientName: string;
  age: number;
  gender: string;
  contactNumber: string;
  diagnosis: string;
  treatment: string;
  assignedTherapist: string;
  status: "Active" | "Completed" | "Scheduled";
  nextSession?: string;
  createdAt: Date;
  updatedAt: Date;
}

let prisma: PrismaClient | null = null;
let isPostgresConnected = false;
let dbConnectionString = "";
const jsonFilePath = path.join(process.cwd(), "clinic_records.json");

// Local fallback database structure
interface JSONDatabase {
  users: User[];
  records: PatientRecord[];
}

// In-memory fallback
let fallbackDb: JSONDatabase = {
  users: [],
  records: []
};

// Seed credentials defaults
const SEED_EMAIL_1 = "admin@axisphysio.com";
const SEED_EMAIL_2 = "suruchidevchaudhary@gmail.com";
const SEED_PASSWORD_PLAIN = "AxisPass2026!"; // Secure default for admin
const SALT_ROUNDS = 10;

// Load JSON database from disk of the container
function loadLocalDB() {
  try {
    if (fs.existsSync(jsonFilePath)) {
      const raw = fs.readFileSync(jsonFilePath, "utf8");
      const parsed = JSON.parse(raw);
      fallbackDb = {
        users: parsed.users || [],
        records: parsed.records || []
      };
    } else {
      saveLocalDB();
    }
  } catch (err) {
    console.error("Local database read error:", err);
  }
}

// Save JSON database to disk
function saveLocalDB() {
  try {
    fs.writeFileSync(jsonFilePath, JSON.stringify(fallbackDb, null, 2), "utf8");
  } catch (err) {
    console.error("Local database write error:", err);
  }
}

// Ensure at least seed admin users exist locally
async function seedLocalDB() {
  const defaultAdminEmails = [SEED_EMAIL_1, SEED_EMAIL_2];
  const hashedPassword = await bcrypt.hash(SEED_PASSWORD_PLAIN, SALT_ROUNDS);

  for (const email of defaultAdminEmails) {
    const exists = fallbackDb.users.some(u => u.email.toLowerCase() === email.toLowerCase());
    if (!exists) {
      fallbackDb.users.push({
        id: "local-admin-" + Math.random().toString(36).substring(2, 9),
        email: email.toLowerCase(),
        password: hashedPassword,
        name: email === SEED_EMAIL_2 ? "Dr. Suruchi (Chief Physiotherapist)" : "Axis Administrator",
        role: "ADMIN",
        createdAt: new Date()
      });
    }
  }
  saveLocalDB();
}

// Initialize and discover database connection state
export async function initDatabase() {
  loadLocalDB();
  await seedLocalDB();

  const url = process.env.DATABASE_URL;
  if (!url) {
    console.log("DATABASE_URL is not set. Using secure local file-backed storage (JSON Sandbox).");
    isPostgresConnected = false;
    dbConnectionString = "";
    return;
  }

  dbConnectionString = url.replace(/:[^:@]+@/, ":****@"); // Blur passwords in logs

  try {
    console.log("DATABASE_URL detected. Attempting to initialize Prisma with NeonDB...");
    prisma = new PrismaClient({
      datasources: {
        db: { url }
      }
    });

    // Test a basic query to verify DB is reachable
    await prisma.$queryRaw`SELECT 1`;
    console.log("Successfully connected to NeonDB/PostgreSQL!");
    isPostgresConnected = true;

    // Seed NeonDB with admin credentials
    await seedPostgresDB();
  } catch (err) {
    console.warn("Could not connect to NeonDB via Prisma, falling back to JSON storage. Error:", err);
    isPostgresConnected = false;
    prisma = null;
  }
}

async function seedPostgresDB() {
  if (!prisma) return;
  try {
    const hashedPassword = await bcrypt.hash(SEED_PASSWORD_PLAIN, SALT_ROUNDS);
    
    // Seed Administrator 1
    const user1 = await prisma.user.upsert({
      where: { email: SEED_EMAIL_1 },
      update: {},
      create: {
        email: SEED_EMAIL_1,
        password: hashedPassword,
        name: "Axis Administrator",
        role: "ADMIN"
      }
    });

    // Seed Owner/Physiotherapist 2
    const user2 = await prisma.user.upsert({
      where: { email: SEED_EMAIL_2 },
      update: {},
      create: {
        email: SEED_EMAIL_2,
        password: hashedPassword,
        name: "Dr. Suruchi (Chief Physiotherapist)",
        role: "ADMIN"
      }
    });

    console.log(`NeonDB admin credentials seeded: ${user1.email}, ${user2.email}`);
  } catch (err) {
    console.error("Failed to seed PostgreSQL admin users:", err);
  }
}

// Helper: Get DB Status
export function getDBStatus() {
  return {
    connected: isPostgresConnected,
    provider: isPostgresConnected ? "Neon Postgres" : "Sandbox JSON",
    connectionStringBlurry: dbConnectionString || "(Local Storage Mode)",
    filePath: jsonFilePath,
    defaultAdminCredentials: {
      email: SEED_EMAIL_1,
      password: SEED_PASSWORD_PLAIN
    }
  };
}

// Auth DB Methods
export async function getUserByEmail(email: string): Promise<User | null> {
  const normEmail = email.toLowerCase().trim();
  
  if (isPostgresConnected && prisma) {
    try {
      const pgUser = await prisma.user.findUnique({ where: { email: normEmail } });
      if (pgUser) {
        return {
          id: pgUser.id,
          email: pgUser.email,
          password: pgUser.password,
          name: pgUser.name,
          role: pgUser.role as "ADMIN" | "STAFF",
          createdAt: pgUser.createdAt
        };
      }
    } catch (err) {
      console.error("Prisma error in getUserByEmail, trying fallback:", err);
    }
  }

  // Fallback
  const u = fallbackDb.users.find(x => x.email.toLowerCase() === normEmail);
  return u || null;
}

export async function createUser(userData: Omit<User, "id" | "createdAt">): Promise<User> {
  const hashedPassword = userData.password 
    ? await bcrypt.hash(userData.password, SALT_ROUNDS)
    : await bcrypt.hash(SEED_PASSWORD_PLAIN, SALT_ROUNDS);

  if (isPostgresConnected && prisma) {
    try {
      const pgUser = await prisma.user.create({
        data: {
          email: userData.email.toLowerCase().trim(),
          password: hashedPassword,
          name: userData.name,
          role: userData.role
        }
      });
      return {
        id: pgUser.id,
        email: pgUser.email,
        name: pgUser.name,
        role: pgUser.role as "ADMIN" | "STAFF",
        createdAt: pgUser.createdAt
      };
    } catch (err) {
      console.error("Prisma error in createUser, falling back to local:", err);
    }
  }

  // Local database create
  const newUser: User = {
    id: "user-" + Math.random().toString(36).substring(2, 9),
    email: userData.email.toLowerCase().trim(),
    password: hashedPassword,
    name: userData.name,
    role: userData.role,
    createdAt: new Date()
  };
  fallbackDb.users.push(newUser);
  saveLocalDB();

  // Strip password out of return
  const { password, ...safeUser } = newUser;
  return safeUser as User;
}

// Clinic Patient Record DB Methods
export async function getPatientRecords(): Promise<PatientRecord[]> {
  if (isPostgresConnected && prisma) {
    try {
      const pgRecords = await prisma.patientRecord.findMany({
        orderBy: { createdAt: "desc" }
      });
      return pgRecords.map(r => ({
        id: r.id,
        patientName: r.patientName,
        age: r.age,
        gender: r.gender,
        contactNumber: r.contactNumber,
        diagnosis: r.diagnosis,
        treatment: r.treatment,
        assignedTherapist: r.assignedTherapist,
        status: r.status as "Active" | "Completed" | "Scheduled",
        nextSession: r.nextSession || undefined,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt
      }));
    } catch (err) {
      console.error("Prisma error in getPatientRecords, using fallback:", err);
    }
  }

  return fallbackDb.records.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
}

export async function createPatientRecord(recordData: Omit<PatientRecord, "id" | "createdAt" | "updatedAt">): Promise<PatientRecord> {
  if (isPostgresConnected && prisma) {
    try {
      const r = await prisma.patientRecord.create({
        data: {
          patientName: recordData.patientName,
          age: recordData.age,
          gender: recordData.gender,
          contactNumber: recordData.contactNumber,
          diagnosis: recordData.diagnosis,
          treatment: recordData.treatment,
          assignedTherapist: recordData.assignedTherapist,
          status: recordData.status,
          nextSession: recordData.nextSession || null
        }
      });
      return {
        id: r.id,
        patientName: r.patientName,
        age: r.age,
        gender: r.gender,
        contactNumber: r.contactNumber,
        diagnosis: r.diagnosis,
        treatment: r.treatment,
        assignedTherapist: r.assignedTherapist,
        status: r.status as "Active" | "Completed" | "Scheduled",
        nextSession: r.nextSession || undefined,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt
      };
    } catch (err) {
      console.error("Prisma error in createPatientRecord, falling back:", err);
    }
  }

  const now = new Date();
  const indexRecord: PatientRecord = {
    id: "record-" + Math.random().toString(36).substring(2, 9),
    patientName: recordData.patientName,
    age: recordData.age,
    gender: recordData.gender,
    contactNumber: recordData.contactNumber,
    diagnosis: recordData.diagnosis,
    treatment: recordData.treatment,
    assignedTherapist: recordData.assignedTherapist,
    status: recordData.status,
    nextSession: recordData.nextSession,
    createdAt: now,
    updatedAt: now
  };
  fallbackDb.records.push(indexRecord);
  saveLocalDB();
  return indexRecord;
}

export async function updatePatientRecord(
  id: string, 
  data: Partial<Omit<PatientRecord, "id" | "createdAt" | "updatedAt">>
): Promise<PatientRecord | null> {
  if (isPostgresConnected && prisma) {
    try {
      // Clean up undefined nextSession -> null for Prisma
      const cleanedData: any = { ...data };
      if ("nextSession" in cleanedData && cleanedData.nextSession === undefined) {
        cleanedData.nextSession = null;
      }
      
      const r = await prisma.patientRecord.update({
        where: { id },
        data: cleanedData
      });
      return {
        id: r.id,
        patientName: r.patientName,
        age: r.age,
        gender: r.gender,
        contactNumber: r.contactNumber,
        diagnosis: r.diagnosis,
        treatment: r.treatment,
        assignedTherapist: r.assignedTherapist,
        status: r.status as "Active" | "Completed" | "Scheduled",
        nextSession: r.nextSession || undefined,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt
      };
    } catch (err) {
      console.error(`Prisma error in updatePatientRecord for id ${id}, falling back:`, err);
    }
  }

  const recordIndex = fallbackDb.records.findIndex(x => x.id === id);
  if (recordIndex === -1) return null;

  const original = fallbackDb.records[recordIndex];
  const updated: PatientRecord = {
    ...original,
    ...data,
    updatedAt: new Date()
  };
  
  fallbackDb.records[recordIndex] = updated;
  saveLocalDB();
  return updated;
}

export async function deletePatientRecord(id: string): Promise<boolean> {
  if (isPostgresConnected && prisma) {
    try {
      await prisma.patientRecord.delete({ where: { id } });
      return true;
    } catch (err) {
      console.error(`Prisma error in deletePatientRecord for id ${id}, falling back:`, err);
    }
  }

  const recordIndex = fallbackDb.records.findIndex(x => x.id === id);
  if (recordIndex === -1) return false;

  fallbackDb.records.splice(recordIndex, 1);
  saveLocalDB();
  return true;
}
